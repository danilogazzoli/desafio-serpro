# data-analytics

**Data Analytics**: Construa um painel analítico para explicar a dinâmica de crimes em Chicago

## Colunas dos dados de crimes

As colunas dos dados de crimes (`chicago-crimes`) são:

- ID: identificação única do registro de ocorrência policial ocorrida em Chicago
- Case_Number: número no Departamento de Polícia de Chicago (Records Division Number), exclusivo do incidente
- Date: data e hora em que o incidente ocorreu, podendo ser uma estimativa
- Block: endereço parcialmente ofuscado (por questões de sigilo) em que o incidente ocorreu, estando na mesma quadra do endereço real
- IUCR: código do Illinois Uniform Crime Reporting (IUCR), sendo diretamente vinculado aos campos Primary Type e Description. Vide lista de códigos IUCR em: https://data.cityofchicago.org/d/c7ck-438e
- Primary_Type: descrição principal do código IUCR
- Description: descrição secundária do código IUCR, uma subcategoria da descrição principal
- Location_Description: descrição do local em que o incidente ocorreu
- Arrest: indica se uma prisão foi feita
- Domestic: indica se o incidente foi doméstico, conforme definido em Illinois Domestic Violence Act
- Beat: indica a batida onde o incidente ocorreu. Uma batida é a menor área geográfica da polícia - cada batida tem um carro policial dedicado. Três a cinco batidas compõem um setor policial e três setores compõem um distrito policial. O Departamento de Polícia de Chicago possui 22 distritos policiais. Vide lista de batidas em: https://data.cityofchicago.org/d/aerh-rz74
- District: indica o distrito policial onde o incidente ocorreu. Vide lista de distritos em: https://data.cityofchicago.org/d/fthy-xz3r
- Ward: ala (distrito do Conselho da Cidade - City Council) onde o incidente ocorreu. Veja a lista de alas em: https://data.cityofchicago.org/d/sp34-6z76
- Community_Area: indica a área comunitária em que o incidente ocorreu. Chicago possui 77 áreas comunitárias. Veja a lista de áreas comunitárias em: https://data.cityofchicago.org/d/cauq-8yn6
- FBI_Code: indica a classificação do crime, conforme descrito no Sistema Nacional de Comunicação de Incidentes do FBI (FBI's National Incident-Based Reporting System - NIBRS). Veja a lista dessas classificações, segundo o Departamento de Polícia de Chicago, em: http://gis.chicagopolice.org/clearmap_crime_sums/crime_types.html
- Latitude: latitude do local em que o incidente ocorreu, sendo deslocada do local real (por questões de sigilo), mas dentro do mesmo bloco
- Longitude: longitude do local em que o incidente ocorreu, sendo deslocada do local real (por questões de sigilo), mas dentro do mesmo bloco

## Colunas dos dados de temperatura

As colunas dos dados de temperatura (`chicago-weather`) são:

- date: data da coleta, no formato "M/D/YY" (ex: "10/26/14" corresponde a "26 de Outubro de 2014")
- month: mês da coleta
- day: dia da coleta
- year: ano da coleta
- maxTemp: temperatura máxima registrada no dia (em graus Fahrenheit)
- meanTemp: temperatura média registrada no dia (em graus Fahrenheit)
- minTemp: temperatura mínima registrada no dia (em graus Fahrenheit)

## Colunas dos dados de censo

As colunas dos dados de censo (`chicago-census`) são:

- Community Area Number: identificação única da área comunitária de Chicago
- COMMUNITY AREA NAME: nome da área comunitária
- PERCENT OF HOUSING CROWDED: percentual de moradias superlotadas
- PERCENT HOUSEHOLDS BELOW POVERTY: percentual de famílias abaixo da pobreza
- PERCENT AGED 16+ UNEMPLOYED: percentual de pessoas acima de 16 anos desempregadas
- PERCENT AGED 25+ WITHOUT HIGH SCHOOL DIPLOMA: percentual de pessoas acima de 25 anos sem diploma do ensino médio
- PERCENT AGED UNDER 18 OR OVER 64: percentual de crianças e idosos (pessoas abaixo de 18 e maiores de 64 anos)
- PER CAPITA INCOME: renda per capita anual (em dólares)
- HARDSHIP INDEX: índice de miséria
