# sumarizacao-textos
Desenvolva um algoritmo capaz de sumarizar um conjunto de textos, em português, sem que seja perdido o significado dos mesmos.
